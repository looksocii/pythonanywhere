from django.apps import AppConfig


class IssueCredentialConfig(AppConfig):
    name = 'issue_credential'

class SelectCredentialConfig(AppConfig):
	name = 'select_credential'